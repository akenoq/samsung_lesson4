window.onload = function() {
    // TODO:: Do your initialization job

    // add eventListener for tizenhwkey
    document.addEventListener('tizenhwkey', function(e) {
        if (e.keyName === "back") {
            try {
                tizen.application.getCurrentApplication().exit();
            } catch (ignore) {}
        }
    });

    /*// Sample code
    var mainPage = document.querySelector('#main');

    mainPage.addEventListener("click", function() {
        var contentText = document.querySelector('#content-text');

        contentText.innerHTML = (contentText.innerHTML === "Basic") ? "Tizen" : "Basic";
    });*/
};

function setTimer() {
	var timer = document.getElementById("timer");
	var alTime = timer.value;
	
	console.log(alTime);
	
	var a = [];
	
	a = alTime.split(':');
	
	console.log(a[0] + ' ' + a[1]);
	
	var date = new Date(2017, 6, 21, a[0], a[1]);
	
	// Set an alarm on January 1st 2012 08:00
	var alarm1 = new tizen.AlarmAbsolute(date);
/*	tizen.alarm.add(alarm1, "org.tizen.app-selector");*/
	
	var url = new tizen.ApplicationControl("http://tizen.org/appcontrol/operation/view");
	tizen.alarm.add(alarm1, "q4UShrecdu.alarm", url);
	
	
	
	function onListInstalledApps(applications) {
	     for (var i = 0; i < applications.length; i++)
	         console.log("ID : " + applications[i].id);
	 }

	 tizen.application.getAppsInfo(onListInstalledApps);
	 
	 function wakeUp() {
			tizen.power.request('CPU', 'CPU_AWAKE');
			tizen.power.request('SCREEN', 'SCREEN_NORMAL');
			tizen.power.turnScreenOn();
		}	

}